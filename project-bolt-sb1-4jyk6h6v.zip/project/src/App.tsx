import React, { useState } from 'react';
import { RotateCcw } from 'lucide-react';

type Player = 'X' | 'O';
type BoardState = (Player | null)[];

function App() {
  const [board, setBoard] = useState<BoardState>(Array(9).fill(null));
  const [currentPlayer, setCurrentPlayer] = useState<Player>('X');
  const [gameOver, setGameOver] = useState(false);

  const checkWinner = (squares: BoardState): Player | null => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
      [0, 4, 8], [2, 4, 6] // Diagonals
    ];

    for (const [a, b, c] of lines) {
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  };

  const handleClick = (index: number) => {
    if (board[index] || gameOver) return;

    const newBoard = [...board];
    newBoard[index] = currentPlayer;
    setBoard(newBoard);

    const winner = checkWinner(newBoard);
    if (winner) {
      setGameOver(true);
    } else if (!newBoard.includes(null)) {
      setGameOver(true);
    } else {
      setCurrentPlayer(currentPlayer === 'X' ? 'O' : 'X');
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setCurrentPlayer('X');
    setGameOver(false);
  };

  const winner = checkWinner(board);
  const isDraw = !winner && !board.includes(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Tic Tac Toe</h1>
          {!gameOver && (
            <p className="text-lg text-gray-600">
              Player {currentPlayer}'s turn
            </p>
          )}
          {winner && (
            <p className="text-xl font-semibold text-green-600">
              Player {winner} wins!
            </p>
          )}
          {isDraw && (
            <p className="text-xl font-semibold text-orange-600">
              It's a draw!
            </p>
          )}
        </div>

        <div className="grid grid-cols-3 gap-3 mb-6">
          {board.map((cell, index) => (
            <button
              key={index}
              onClick={() => handleClick(index)}
              className={`h-24 text-4xl font-bold rounded-lg transition-colors duration-200
                ${!cell && !gameOver ? 'hover:bg-gray-100' : ''}
                ${cell === 'X' ? 'text-blue-600' : 'text-red-600'}
                ${!cell ? 'bg-gray-50' : 'bg-white'}
                border-2 border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400`}
              disabled={gameOver || !!cell}
            >
              {cell}
            </button>
          ))}
        </div>

        <button
          onClick={resetGame}
          className="w-full py-3 px-6 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg
            font-semibold flex items-center justify-center gap-2 hover:from-blue-600 hover:to-blue-700
            transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
        >
          <RotateCcw size={20} />
          New Game
        </button>
      </div>
    </div>
  );
}

export default App;